import React from "react";
import PropTypes from "prop-types";

function Hello2({
  id = "0",
  name = "이름없음",
  children = "별명없음",
  color = "black",
}) {
  return (
    <>
      <div style={{ color }}>{id}</div>
      <div style={{ color }}>{name}</div>
      <div style={{ color }}>{children}</div>
    </>
  );
}

Hello2.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
};

export default Hello2;
